package com.dz.arabic.bag

import android.app.Application
import androidx.room.Room
import com.dz.arabic.bag.data.AppDatabase

class BagApplication : Application() {
    val db: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "bag_teacher_arabic.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
