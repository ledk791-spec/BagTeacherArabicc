package com.dz.arabic.bag

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dz.arabic.bag.data.*
import com.dz.arabic.bag.ui.theme.BagTheme
import com.dz.arabic.bag.utils.FileUtils
import kotlinx.coroutines.launch
import java.io.File

private val groups=listOf("س1 علوم","س1 آداب","س2 علوم","س2 آداب","س2 لغات","س3 علوم","س3 آداب","س3 لغات")
private val sections=listOf("المذكرات","وثائق الأستاذ","الكتاب المدرسي","الدفتر اليومي","دفتر التنقيط","تحضير الدروس","فيديوهات تعليمية","خرائط ذهنية","بنك الاختبارات والفروض","أنشطة وتمارين","المكتبة")

class MainActivity:ComponentActivity(){
    private val pickFiles=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){ uris ->
        if(uris.isNotEmpty()) pendingUris=uris
    }
    private var pendingUris:List<Uri> = emptyList()

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        val db=(application as BagApplication).db
        setContent{ BagTheme{ App(db,pickFiles){ pendingUris=emptyList() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App(db:AppDatabase,pick:(Array<String>)->Unit,clear:()->Unit){
    val scope=rememberCoroutineScope()
    var screen by remember{mutableStateOf("الرئيسية")}
    var group by remember{mutableStateOf(groups[0])}
    var term by remember{mutableStateOf(1)}
    var admin by remember{mutableStateOf(false)}
    var pinDialog by remember{mutableStateOf(false)}
    val resources by db.resources().all().collectAsStateWithLifecycle(emptyList())
    val diary by db.diary().all().collectAsStateWithLifecycle(emptyList())

    if(pinDialog) PinDialog(
        onDismiss={pinDialog=false},
        onOk={ pinDialog=false; admin=true }
    )

    Scaffold(topBar={
        TopAppBar(
            title={Text(screen)},
            navigationIcon=if(screen!="الرئيسية")({IconButton({screen="الرئيسية"}){Icon(Icons.Default.ArrowBack,"رجوع")}}) else null,
            actions={
                if(screen=="الرئيسية") IconButton({pinDialog=true}){Icon(if(admin)Icons.Default.LockOpen else Icons.Default.Lock,"وضع المدير")}
            }
        )
    }){pad->
        when(screen){
            "الرئيسية"->Home({screen=it})
            "الدفتر اليومي"->DiaryPage(diary,admin,db,pad)
            "دفتر التنقيط"->GradePage(db,admin,group,{group=it},term,{term=it},pad)
            "المفضلة"->ResourceList(resources.filter{it.favorite},admin,db,pad)
            else->ResourcePage(screen,group,groups,{group=it},resources.filter{r->r.section==screen},admin,db,pad)
        }
    }
}

@Composable private fun Home(open:(String)->Unit){
    LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize().padding(12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        items(sections+listOf("المفضلة")){s->
            Card(onClick={open(s)},modifier=Modifier.height(110.dp)){
                Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
                    Icon(if(s=="دفتر التنقيط")Icons.Default.Grading else if(s=="الدفتر اليومي")Icons.Default.EditNote else Icons.Default.Folder,null,Modifier.size(34.dp))
                    Spacer(Modifier.height(7.dp)); Text(s)
                }
            }
        }
    }
}

@Composable private fun PinDialog(onDismiss:()->Unit,onOk:()->Unit){
    var pin by remember{mutableStateOf("")}
    var error by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("وضع المدير")},text={
        Column{Text("أدخل الرمز. الرمز الافتراضي الأولي: 1234");OutlinedTextField(pin,{pin=it},"الرمز",singleLine=true);if(error)Text("الرمز غير صحيح")}}
        ,confirmButton={Button({if(pin=="1234")onOk()else error=true}){Text("دخول")}},dismissButton={TextButton(onDismiss){Text("إلغاء")}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun ResourcePage(section:String,current:String,groups:List<String>,setGroup:(String)->Unit,items:List<ResourceItem>,admin:Boolean,db:AppDatabase,pad:PaddingValues){
    var query by remember{mutableStateOf("")}
    var selectedGroup by remember{mutableStateOf(current)}
    val scope=rememberCoroutineScope()
    val context=androidx.compose.ui.platform.LocalContext.current
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        scope.launch{uris.forEach{u->
            val f=FileUtils.copyToApp(context,u) ?: return@forEach
            db.resources().insert(ResourceItem(title=FileUtils.queryName(context,u),path=f.absolutePath,mime=context.contentResolver.getType(u)?:"application/octet-stream",section=section,group=if(section in listOf("المذكرات","فيديوهات تعليمية","خرائط ذهنية","بنك الاختبارات والفروض"))selectedGroup else null))
        }}
    }
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(query,{query=it},Modifier.weight(1f),label={Text("بحث")},singleLine=true)
            if(admin){IconButton({launcher.launch(arrayOf("*/*"))}){Icon(Icons.Default.Add,"إضافة عدة ملفات")}}
        }
        if(section in listOf("المذكرات","فيديوهات تعليمية","خرائط ذهنية","بنك الاختبارات والفروض")){
            ScrollableTabRow(selectedTabIndex=groups.indexOf(selectedGroup)){groups.forEach{g->Tab(selectedGroup==g,{selectedGroup=g},{Text(g)})}}
        }
        ResourceList(items.filter{it.title.contains(query,true) && (it.group==null || it.group==selectedGroup)},admin,db,PaddingValues(0.dp))
    }
}

@Composable private fun ResourceList(items:List<ResourceItem>,admin:Boolean,db:AppDatabase,pad:PaddingValues){
    val context=androidx.compose.ui.platform.LocalContext.current
    val scope=rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        items(items,key={it.id}){r->
            Card{Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){Text(r.title);Text(r.section,style=MaterialTheme.typography.labelSmall)}
                IconButton({scope.launch{db.resources().update(r.copy(favorite=!r.favorite))}}){Icon(if(r.favorite)Icons.Default.Star else Icons.Default.StarBorder,"مفضلة")}
                IconButton({openFile(context,r.path,r.mime)}){Icon(Icons.Default.OpenInNew,"فتح")}
                if(admin)IconButton({scope.launch{db.resources().delete(r);File(r.path).delete()}}){Icon(Icons.Default.Delete,"حذف")}
            }}
        }
    }
}

private fun openFile(context:android.content.Context,path:String,mime:String){
    val file=File(path); if(!file.exists())return
    val uri=FileProvider.getUriForFile(context,context.packageName+".fileprovider",file)
    context.startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,mime);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})
}

@Composable private fun DiaryPage(entries:List<DiaryEntry>,admin:Boolean,db:AppDatabase,pad:PaddingValues){
    var show by remember{mutableStateOf(false)}
    var q by remember{mutableStateOf("")}
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Row{OutlinedTextField(q,{q=it},Modifier.weight(1f),label={Text("بحث في الدفتر")});Spacer(Modifier.width(8.dp));if(admin)Button({show=true}){Text("+ إضافة")}}
        LazyColumn(contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(entries.filter{it.title.contains(q,true)||it.activities.contains(q,true)||it.group.contains(q,true)}){e->
                Card{Column(Modifier.padding(12.dp)){Text("${e.date} — ${e.time} — ${e.group}",style=MaterialTheme.typography.labelMedium);Text(e.title,style=MaterialTheme.typography.titleMedium);Text(e.activities);if(admin)TextButton({scope.launch{db.diary().delete(e)}}){Text("حذف")}}}
            }
        }
    }
    if(show)DiaryDialog({show=false}){e->scope.launch{db.diary().insert(e)};show=false}
}

@Composable private fun DiaryDialog(close:()->Unit,save:(DiaryEntry)->Unit){
    var date by remember{mutableStateOf("")};var time by remember{mutableStateOf("")};var group by remember{mutableStateOf(groups[0])};var title by remember{mutableStateOf("")};var act by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=close,title={Text("إضافة إلى الدفتر اليومي")},text={
        Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
            OutlinedTextField(date,{date=it},"التاريخ")
            OutlinedTextField(time,{time=it},"التوقيت")
            OutlinedTextField(group,{group=it},"القسم")
            OutlinedTextField(title,{title=it},"الوحدة التعليمية / عنوان الدرس")
            OutlinedTextField(act,{act=it},"النشاطات البيداغوجية / محتوى الدرس",minLines=4)
        }},
        confirmButton={Button({save(DiaryEntry(date=date,time=time,group=group,title=title,activities=act))}){Text("حفظ")}},
        dismissButton={TextButton(close){Text("إلغاء")}})
}

@Composable private fun GradePage(db:AppDatabase,admin:Boolean,group:String,setGroup:(String)->Unit,term:Int,setTerm:(Int)->Unit,pad:PaddingValues){
    val students by db.students().byGroup(group).collectAsStateWithLifecycle(emptyList())
    val scores by db.scores().byGroup(group,term).collectAsStateWithLifecycle(emptyList())
    val scope=rememberCoroutineScope()
    LaunchedEffect(group){if(students.isEmpty()&&admin)db.students().insertAll((1..45).map{Student(group,it)})}
    Column(Modifier.fillMaxSize().padding(pad)){
        ScrollableTabRow(selectedTabIndex=groups.indexOf(group)){groups.forEach{g->Tab(group==g,{setGroup(g)},{Text(g)})}}
        Row(Modifier.padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){(1..3).forEach{t->FilterChip(t==term,{setTerm(t)},{Text("الفصل $t")})}}
        LazyColumn(contentPadding=PaddingValues(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            items(students,key={it.number}){s->
                val sc=scores.firstOrNull{it.number==s.number}?:Score(group,s.number,term)
                Card{Column(Modifier.padding(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("${s.number}.",Modifier.width(38.dp))
                        if(admin)OutlinedTextField(s.name,{n->scope.launch{db.students().update(s.copy(name=n))}},Modifier.weight(1f),singleLine=true)
                        else Text(s.name,Modifier.weight(1f))
                        Text("م.م ${"%.1f".format(sc.continuous())}")
                    }
                    if(admin){
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ScoreBox("س",sc.behavior){v->scope.launch{db.scores().save(sc.copy(behavior=v))}};ScoreBox("غ",sc.absences){v->scope.launch{db.scores().save(sc.copy(absences=v))}};ScoreBox("ت",sc.delays){v->scope.launch{db.scores().save(sc.copy(delays=v))}};ScoreBox("أد",sc.tools){v->scope.launch{db.scores().save(sc.copy(tools=v))}}}
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ScoreBox("ك",sc.copybook){v->scope.launch{db.scores().save(sc.copy(copybook=v))}};ScoreBox("مش",sc.participation){v->scope.launch{db.scores().save(sc.copy(participation=v))}};ScoreBox("فع",sc.efficiency){v->scope.launch{db.scores().save(sc.copy(efficiency=v))}};ScoreBox("ف",sc.teamwork){v->scope.launch{db.scores().save(sc.copy(teamwork=v))}}}
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ScoreBox("مب",sc.initiative){v->scope.launch{db.scores().save(sc.copy(initiative=v))}};ScoreBox("و",sc.homework){v->scope.launch{db.scores().save(sc.copy(homework=v))}};ScoreBox("ف1",sc.quiz1){v->scope.launch{db.scores().save(sc.copy(quiz1=v))}};ScoreBox("ف2",sc.quiz2){v->scope.launch{db.scores().save(sc.copy(quiz2=v))}};ScoreBox("اخت",sc.exam){v->scope.launch{db.scores().save(sc.copy(exam=v))}}}
                    }
                    Text("النتيجة: ${"%.2f".format(sc.finalAverage())}/20")
                }}
            }
        }
    }
}

@Composable private fun ScoreBox(label:String,value:Float,onChange:(Float)->Unit){
    var text by remember(value){mutableStateOf(if(value==0f)"" else value.toString())}
    OutlinedTextField(text,{v->text=v;v.toFloatOrNull()?.let{if(it in 0f..3f)onChange(it)}},Modifier.width(72.dp),label={Text(label)},singleLine=true)
}
