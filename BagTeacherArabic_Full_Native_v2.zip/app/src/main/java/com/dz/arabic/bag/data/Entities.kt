package com.dz.arabic.bag.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="students", primaryKeys=["group","number"])
data class Student(
    val group:String,
    val number:Int,
    val name:String = "تلميذ $number"
)

@Entity(tableName="scores", primaryKeys=["group","number","term"])
data class Score(
    val group:String,
    val number:Int,
    val term:Int,
    val behavior:Float=0f, val absences:Float=0f, val delays:Float=0f,
    val tools:Float=0f, val copybook:Float=0f, val participation:Float=0f,
    val efficiency:Float=0f, val teamwork:Float=0f, val initiative:Float=0f,
    val homework:Float=0f, val quiz1:Float=0f, val quiz2:Float=0f, val exam:Float=0f
) {
    fun continuous() = (behavior+absences+delays+tools+copybook+participation+efficiency+teamwork+initiative+homework).coerceAtMost(20f)
    fun finalAverage() = ((continuous()+quiz1+quiz2)/3f + exam*2f)/3f
}

@Entity(tableName="diary")
data class DiaryEntry(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val date:String,
    val time:String,
    val group:String,
    val title:String,
    val activities:String
)

@Entity(tableName="resources")
data class ResourceItem(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val title:String,
    val path:String,
    val mime:String,
    val section:String,
    val group:String?,
    val category:String?,
    val favorite:Boolean=false
)
