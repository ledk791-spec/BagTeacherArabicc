package com.dz.arabic.bag.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface StudentDao {
    @Query("SELECT * FROM students WHERE `group`=:group ORDER BY number")
    fun byGroup(group:String):Flow<List<Student>>
    @Update suspend fun update(s:Student)
    @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun insertAll(s:List<Student>)
}
@Dao interface ScoreDao {
    @Query("SELECT * FROM scores WHERE `group`=:group AND term=:term ORDER BY number")
    fun byGroup(group:String,term:Int):Flow<List<Score>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun save(s:Score)
}
@Dao interface DiaryDao {
    @Query("SELECT * FROM diary ORDER BY id DESC") fun all():Flow<List<DiaryEntry>>
    @Insert suspend fun insert(e:DiaryEntry)
    @Update suspend fun update(e:DiaryEntry)
    @Delete suspend fun delete(e:DiaryEntry)
}
@Dao interface ResourceDao {
    @Query("SELECT * FROM resources ORDER BY id DESC") fun all():Flow<List<ResourceItem>>
    @Query("SELECT * FROM resources WHERE section=:section ORDER BY id DESC")
    fun section(section:String):Flow<List<ResourceItem>>
    @Query("SELECT * FROM resources WHERE favorite=1 ORDER BY id DESC")
    fun favorites():Flow<List<ResourceItem>>
    @Insert suspend fun insert(r:ResourceItem)
    @Update suspend fun update(r:ResourceItem)
    @Delete suspend fun delete(r:ResourceItem)
}
