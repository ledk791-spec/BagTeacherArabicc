package com.dz.arabic.bag.utils

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

object FileUtils {
    fun copyToApp(context:Context, uri:Uri):File? = try {
        val name = queryName(context,uri).replace(Regex("[^A-Za-z0-9._ -]"), "_")
        val dir=File(context.filesDir,"resources").apply{mkdirs()}
        val file=File(dir,"${System.currentTimeMillis()}_$name")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            FileOutputStream(file).use { output -> input.copyTo(output) }
        }
        file
    } catch(_:Exception){null}

    fun queryName(context:Context,uri:Uri):String{
        var n="ملف"
        context.contentResolver.query(uri,null,null,null,null)?.use{
            if(it.moveToFirst()){
                val i=it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if(i>=0)n=it.getString(i)
            }
        }
        return n
    }
}
