package com.dz.arabic.bag.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities=[Student::class,Score::class,DiaryEntry::class,ResourceItem::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
    abstract fun students():StudentDao
    abstract fun scores():ScoreDao
    abstract fun diary():DiaryDao
    abstract fun resources():ResourceDao
}
