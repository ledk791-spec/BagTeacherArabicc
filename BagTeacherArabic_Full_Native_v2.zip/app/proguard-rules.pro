# Project rules intentionally minimal for reliable first release.
